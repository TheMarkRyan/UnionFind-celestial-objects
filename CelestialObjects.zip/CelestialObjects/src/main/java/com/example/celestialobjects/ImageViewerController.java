package com.example.celestialobjects;


import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.image.PixelReader;
import javafx.scene.image.PixelWriter;
import javafx.scene.image.WritableImage;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.text.Font;
import javafx.stage.FileChooser;



import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.*;


public class ImageViewerController implements Initializable {


    private ToggleGroup coloringModeToggleGroup;


    @FXML
    private Pane overlayPane;

    @FXML
    private Slider thresholdSlider;

    @FXML
    private ToggleButton randomColorToggle;

    @FXML
    private ToggleButton averageColorToggle;

    @FXML
    private ImageView originalImageView;

    @FXML
    private ImageView grayscaleImageView;

    @FXML
    private Label imageSizeLabel;

    @FXML
    private Label filenameLabel;

    @FXML
    private Label celestialObjectCountLabel;


    @FXML
    private void handleOpenImageAction(ActionEvent event) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Open Image");
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.gif"),
                new FileChooser.ExtensionFilter("All Files", "*.*")
        );
        File selectedFile = fileChooser.showOpenDialog(null);
        if (selectedFile != null) {
            try {
                Image originalImage = new Image(selectedFile.toURI().toURL().toString());
                originalImageView.setImage(originalImage);
                imageSizeLabel.setText(originalImage.getWidth() + "x" + originalImage.getHeight());
                filenameLabel.setText(selectedFile.getName());

                WritableImage grayscaleImage = convertToGrayscale(originalImage);
                grayscaleImageView.setImage(grayscaleImage);

            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    @FXML
    private void handleDetectCelestialObjects(ActionEvent event) {
        Image originalImage = originalImageView.getImage();
        if (originalImage != null) {
            WritableImage grayscaleImage = convertToGrayscale(originalImage);
            double threshold = thresholdSlider.getValue();
            List<CelestialObject> celestialObjects = CelestialObjectDetector.detectCelestialObjects(grayscaleImage, threshold);

            celestialObjectCountLabel.setText("Celestial objects detected: " + celestialObjects.size());

            // Determine the selected coloring mode
            boolean useAverageColor = averageColorToggle.isSelected();

            // Color the celestial objects according to the selected mode
            colorCelestialObjects(grayscaleImage, celestialObjects, useAverageColor);

            grayscaleImageView.setImage(grayscaleImage);
            drawCelestialObjectCircles(celestialObjects, grayscaleImage);
        }
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        thresholdSlider.valueProperty().addListener((observable, oldValue, newValue) -> {
            if (grayscaleImageView.getImage() != null) {
                handleDetectCelestialObjects(null);
            }
        });

        coloringModeToggleGroup = new ToggleGroup();
        randomColorToggle.setToggleGroup(coloringModeToggleGroup);
        averageColorToggle.setToggleGroup(coloringModeToggleGroup);
        randomColorToggle.setSelected(true);

        coloringModeToggleGroup.selectedToggleProperty().addListener((observable, oldValue, newValue) -> {
            if (grayscaleImageView.getImage() != null) {
                handleDetectCelestialObjects(null);
            }
        });
    }





    private WritableImage convertToGrayscale(Image originalImage) {
        WritableImage grayscaleImage = new WritableImage((int) originalImage.getWidth(), (int) originalImage.getHeight());
        PixelReader pixelReader = originalImage.getPixelReader();
        PixelWriter pixelWriter = grayscaleImage.getPixelWriter();
        for (int y = 0; y < originalImage.getHeight(); y++) {
            for (int x = 0; x < originalImage.getWidth(); x++) {
                int pixel = pixelReader.getArgb(x, y);
                int red = (pixel >> 16) & 0xff;
                int green = (pixel >> 8) & 0xff;
                int blue = (pixel) & 0xff;
                int gray = (int) (0.21 * red + 0.72 * green + 0.07 * blue);
                int newPixel = (pixel & 0xff000000) | (gray << 16) | (gray << 8) | gray;
                pixelWriter.setArgb(x, y, newPixel);
            }
        }
        return grayscaleImage;

    }



    private void drawCelestialObjectCircles(List<CelestialObject> celestialObjects, WritableImage image) {
        int width = (int) image.getWidth();
        int height = (int) image.getHeight();
        PixelReader pixelReader = image.getPixelReader();

        overlayPane.getChildren().clear();
        double scaleX = originalImageView.getBoundsInParent().getWidth() / originalImageView.getImage().getWidth();
        double scaleY = originalImageView.getBoundsInParent().getHeight() / originalImageView.getImage().getHeight();

        int labelIndex = 1;
        for (CelestialObject celestialObject : celestialObjects) {
            int x = celestialObject.getX();
            int y = celestialObject.getY();
            int size = celestialObject.getSize();

            // Approximate the radius of the celestial object
            double radius = Math.sqrt(size / Math.PI);

            Circle circle = new Circle(x * scaleX, y * scaleY, radius * Math.min(scaleX, scaleY), Color.TRANSPARENT);
            circle.setStroke(Color.BLUE);
            circle.setStrokeWidth(0.5);
            circle.setFill(Color.TRANSPARENT);
            overlayPane.getChildren().add(circle);

            // Add a label to the circle
            Label label = new Label(Integer.toString(labelIndex));
            label.setTextFill(Color.WHITE);
            label.setFont(new Font("Arial", 10)); // Set the font size to 10
            label.setLayoutX(x * scaleX - label.getWidth() / 2);
            label.setLayoutY(y * scaleY - label.getHeight() / 2);
            overlayPane.getChildren().add(label);

            Tooltip tooltip = new Tooltip("Name: " + celestialObject.getName() +
                    "\nSize: " + celestialObject.getSize() +
                    "\nCoordinates: (" + celestialObject.getX() + ", " + celestialObject.getY() + ")");
            Tooltip.install(circle, tooltip);

            labelIndex++;
        }
    }
    private Color calculateAverageColor(UnionFind uf, int root, WritableImage image) {
        int width = (int) image.getWidth();
        int height = (int) image.getHeight();
        PixelReader pixelReader = image.getPixelReader();

        int size = uf.getSize(root);
        double rSum = 0;
        double gSum = 0;
        double bSum = 0;

        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                if (uf.find(y * width + x) == root) {
                    Color pixelColor = pixelReader.getColor(x, y);
                    rSum += pixelColor.getRed();
                    gSum += pixelColor.getGreen();
                    bSum += pixelColor.getBlue();
                }
            }
        }

        return Color.color(rSum / size, gSum / size, bSum / size);
    }
    private void colorCelestialObjects(WritableImage image, List<CelestialObject> celestialObjects, boolean useAverageColor) {
        int width = (int) image.getWidth();
        int height = (int) image.getHeight();
        PixelReader pixelReader = image.getPixelReader();
        PixelWriter pixelWriter = image.getPixelWriter();

        for (CelestialObject celestialObject : celestialObjects) {
            Color color;
            if (useAverageColor) {
                color = celestialObject.getAverageColor();
            } else {
                color = Color.color(Math.random(), Math.random(), Math.random());
            }

            if (color != null) {
                for (int y = 0; y < height; y++) {
                    for (int x = 0; x < width; x++) {
                        if (celestialObject.containsPixel(pixelReader.getArgb(x, y))) {
                            pixelWriter.setColor(x, y, color);
                        }
                    }
                }
            }
        }
    }



    public void handleMouseEntered(MouseEvent event) {
        ImageView sourceImageView = (ImageView) event.getSource();
        // Position and display the overlay based on the mouse coordinates.
    }

    public void handleMouseExited(MouseEvent event) {
        // Hide the overlay.
    }



}





