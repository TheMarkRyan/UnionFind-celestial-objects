package com.example.celestialobjects;

import java.util.*;

public class UnionFind {
    private int[] parent;
    private int[] size;
    private int width;

    public UnionFind(int n, int width) {
        this.width = width;
        parent = new int[n];
        size = new int[n];

        for (int i = 0; i < n; i++) {
            parent[i] = i;
            size[i] = 1;
        }
    }

    public int find(int x) {
        if (parent[x] != x) {
            parent[x] = find(parent[x]);
        }
        return parent[x];
    }

    public void union(int x, int y) {
        int rootX = find(x);
        int rootY = find(y);

        if (rootX != rootY) {
            if (size[rootX] < size[rootY]) {
                int temp = rootX;
                rootX = rootY;
                rootY = temp;
            }
            parent[rootY] = rootX;
            size[rootX] += size[rootY];
        }
    }

    public int getSize(int x) {
        return size[find(x)];
    }

    public List<CelestialObject> getCelestialObjects(int minSize) {
        List<CelestialObject> celestialObjects = new ArrayList<>();
        for (int i = 0; i < parent.length; i++) {
            if (i == parent[i] && size[i] >= minSize) {
                int xSum = 0;
                int ySum = 0;
                for (int j = 0; j < parent.length; j++) {
                    if (find(j) == i) {
                        xSum += j % width;
                        ySum += j / width;
                    }
                }
                int x = xSum / size[i];
                int y = ySum / size[i];
                celestialObjects.add(new CelestialObject(i, size[i], x, y, "Celestial Object " + (celestialObjects.size() + 1)));
            }
        }
        return celestialObjects;
    }
}