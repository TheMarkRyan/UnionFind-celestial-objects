package com.example.celestialobjects;

import javafx.scene.image.PixelReader;
import javafx.scene.image.WritableImage;
import javafx.scene.paint.Color;

import java.util.Comparator;
import java.util.List;

public class CelestialObjectDetector {

    private static final int MIN_CLUSTER_SIZE = 5;

    public static List<CelestialObject> detectCelestialObjects(WritableImage image, double threshold) {
        UnionFind uf = performCelestialObjectDetection(image, threshold);

        List<CelestialObject> celestialObjects = uf.getCelestialObjects(MIN_CLUSTER_SIZE);

        // Sort the celestial objects in descending order of their size
        celestialObjects.sort(Comparator.comparingInt(CelestialObject::getSize).reversed());

        return celestialObjects;
    }

    private static UnionFind performCelestialObjectDetection(WritableImage image, double threshold) {
        int width = (int) image.getWidth();
        int height = (int) image.getHeight();
        PixelReader pixelReader = image.getPixelReader();

        UnionFind uf = new UnionFind(width * height, width);

        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                if (pixelReader.getColor(x, y).getBrightness() > threshold) {
                    int[] dx = {-1, 0, 1, 0, -1, 1, 1, -1};
                    int[] dy = {0, 1, 0, -1, 1, 1, -1, -1};

                    for (int i = 0; i < 8; i++) {
                        int nx = x + dx[i];
                        int ny = y + dy[i];

                        if (nx >= 0 && nx < width && ny >= 0 && ny < height && pixelReader.getColor(nx, ny).getBrightness() > threshold) {
                            uf.union(y * width + x, ny * width + nx);
                        }
                    }
                }
            }
        }

        for (CelestialObject celestialObject : uf.getCelestialObjects(MIN_CLUSTER_SIZE)) {
            Color averageColor = calculateAverageColor(uf, celestialObject.getRoot(), image);
            celestialObject.setAverageColor(averageColor);
        }

        return uf;
    }

    private static Color calculateAverageColor(UnionFind uf, int root, WritableImage image) {
        int width = (int) image.getWidth();
        int height = (int) image.getHeight();
        PixelReader pixelReader = image.getPixelReader();

        int size = uf.getSize(root);
        double rSum = 0;
        double gSum = 0;
        double bSum = 0;

        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                if (uf.find(y * width + x) == root) {
                    Color pixelColor = pixelReader.getColor(x, y);
                    rSum += pixelColor.getRed();
                    gSum += pixelColor.getGreen();
                    bSum += pixelColor.getBlue();
                }
            }
        }

        return Color.color(rSum / size, gSum / size, bSum / size);
    }
}
