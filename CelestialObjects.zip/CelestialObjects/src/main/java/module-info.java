module com.example.celestialobjects {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.celestialobjects to javafx.fxml;
    exports com.example.celestialobjects;
}