import com.example.celestialobjects.CelestialObject;
import com.example.celestialobjects.UnionFind;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class UnionFindTest {

    private UnionFind uf;

    @BeforeEach
    void setUp() {
        // Total number of objects is 10 and width is 5
        uf = new UnionFind(10, 5);
    }

    @Test
    void find() {
        // Initially, each object is its own parent
        for(int i=0; i<10; i++){
            assertEquals(i, uf.find(i));
        }
    }

    @Test
    void union() {
        // Create union of 0 and 1
        uf.union(0, 1);

        // Root of 0 and 1 should be same now
        assertEquals(uf.find(0), uf.find(1));
    }

    @Test
    void getSize() {
        // Initially, size of each set is 1
        for(int i=0; i<10; i++){
            assertEquals(1, uf.getSize(i));
        }

        // Create union of 0 and 1
        uf.union(0, 1);

        // Size of set containing 0 and 1 should be 2
        assertEquals(2, uf.getSize(0));
        assertEquals(2, uf.getSize(1));
    }

    @Test
    void getCelestialObjects() {
        // Create union of 0, 1 and 2
        uf.union(0, 1);
        uf.union(0, 2);

        // Get celestial objects of minimum size 2
        List<CelestialObject> celestialObjects = uf.getCelestialObjects(2);

        // There should be 1 celestial object of size 2
        assertEquals(1, celestialObjects.size());
        assertEquals(3, celestialObjects.get(0).getSize());
    }
}
