
import com.example.celestialobjects.CelestialObject;
import javafx.scene.paint.Color;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CelestialObjectTest {

    private CelestialObject co;

    @BeforeEach
    void setUp() {
        co = new CelestialObject(1, 10, 5, 5, "Celestial Object 1");
        co.setWidth(10);
        co.setHeight(10);
        co.setAverageColor(Color.WHITE);
    }

    @Test
    void getRoot() {
        assertEquals(1, co.getRoot());
    }

    @Test
    void getSize() {
        assertEquals(10, co.getSize());
    }

    @Test
    void getX() {
        assertEquals(5, co.getX());
    }

    @Test
    void getY() {
        assertEquals(5, co.getY());
    }

    @Test
    void getName() {
        assertEquals("Celestial Object 1", co.getName());
    }

    @Test
    void getWidth() {
        assertEquals(10, co.getWidth());
    }

    @Test
    void getHeight() {
        assertEquals(10, co.getHeight());
    }

    @Test
    void getAverageColor() {
        assertEquals(Color.WHITE, co.getAverageColor());
    }

    @Test
    void containsPixel() {
        assertTrue(co.containsPixel(1));
        assertFalse(co.containsPixel(2));
    }

    @Test
    void testToString() {
        String expectedOutput = "CelestialObject{" +
                "width=10, height=10, root=1, size=10, x=5, y=5, name='Celestial Object 1', averageColor=" + Color.WHITE.toString() +
                '}';
        assertEquals(expectedOutput, co.toString());

    }
}